setwd("C:/Users/User/Desktop/UNIR/AnalisisInterpretacionDatos/Actividad 2/ARIMA_R")

#Se instala los paquetes necesarios
# install.packages("tseries")
# install.packages("astsa")
# install.packages("forecast")
# install.packages("foreign")
# install.packages("quantmod")

#Se activa las funciones de los paquetes anteriores
library("tseries")
library("astsa")
library("forecast")
library("foreign")
library("quantmod")
library("lubridate")
library("ggplot2")
library(readxl)

#Muestra
#Casos totales confirmados en el periodo 14 de noviembre 2021 hasta 14 de enero de 2022
d <- read_excel("Datos.xlsx")

#Se convierte a serie temporal
d$Casos <- ts(d$Casos)

plot(d$Día,d$Casos,type="l",col="red",main="Evolución casos totales confirmados",
     xlab="Fecha", ylab="")


#Modelo

# 1.) Estacionariedad
adf.test(d$Casos,alternative = "stationary")
Casos_dif <- diff(d$Casos)
adf.test(Casos_dif,alternative = "stationary")
Casos_dif2 <- diff(Casos_dif)
adf.test(Casos_dif2,alternative = "stationary")
#Se logra estacionaria con una diferencia

plot(Casos_dif2,type="o",col="red",main="Evolución casos totales confirmados",
     xlab="Fecha")

# 2.) Parámetros modelo ARIMA (p,d,q)
par(mfrow=c(2,1))
#Funcion de autocorrelacion: número de medias móviles
acf(Casos_dif2,frequency=1,main="Evolución casos totales confirmados",ylab="Autocorrelación",col="red",xlab="")
#Funcion de autocorrelacion parcial: número de autoregresivos
pacf(Casos_dif2,frequency=1,main="",ylab="Autocorrelación Parcial",col="red",xlab="")


# 3.) Modelo ARIMA (1,2,3)
modelo <- arima(d$Casos,order = c(1,2,3))
modelo

# 4.) Evaluación del modelo
Box.test(residuals(modelo),type = "Ljung-Box")
tsdiag(modelo)
plot(modelo)
# error <- residuals(modelo)
# plot(error)

# 5.) Pronostico
Pro <- forecast::forecast(modelo,h=12)
plot(Pro,col="red",main="Pronóstico a 12 días")


